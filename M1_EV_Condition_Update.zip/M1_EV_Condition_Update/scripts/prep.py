"""M5 handover: fit this preprocessor inside EACH training/CV fold.
This module constructs preprocessing only; it does not fit a final price model.
"""
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler,OneHotEncoder
from sklearn.impute import SimpleImputer,KNNImputer

NUMERIC=['age','mileage','seller_rating','driver_rating']
BINARY=['accidents_or_damage','one_owner','personal_use_only']
CATEGORICAL=['model_line','drivetrain']
PRICE_FEATURES=NUMERIC+BINARY+CATEGORICAL
FORBIDDEN_PRICE_FEATURES=['listing_id','source_excel_row','price','log_price','price_drop','price_drop_raw','price_drop_was_missing','initial_price','price_cut_flag','iqr_outlier','iso_outlier','iso_anomaly_score','confirmed_error_flag','error_review_status','iqr_reference_n','iqr_reference_scope']

def make_preprocessor(method='median', include_condition=False):
    """Median is the M1 pilot winner; M5 may revalidate with richer models.
    Four continuous fields differ between methods; history fields always use mode.
    Standardisation precedes KNN so mileage cannot dominate neighbour distance.
    """
    if method not in ['median','knn']: raise ValueError('method must be median or knn')
    imputer=SimpleImputer(strategy='median') if method=='median' else KNNImputer(n_neighbors=5)
    from condition_features import CONDITION_NUMERIC, CONDITION_BINARY, CONDITION_CATEGORY
    numeric = NUMERIC + (CONDITION_NUMERIC if include_condition else [])
    binary = BINARY + (CONDITION_BINARY if include_condition else [])
    category = CATEGORICAL + (CONDITION_CATEGORY if include_condition else [])
    return ColumnTransformer([
        ('numeric',Pipeline([('scale',StandardScaler()),('impute',imputer)]),numeric),
        ('history',SimpleImputer(strategy='most_frequent'),binary),
        ('category',Pipeline([('impute',SimpleImputer(strategy='constant',fill_value='Unknown')),('encode',OneHotEncoder(handle_unknown='ignore'))]),category)
    ])

def training_rows_only(df):
    """Apply only AFTER selecting a training fold. Never call on validation/test."""
    return df.loc[df.confirmed_error_flag.eq(0)].copy()
